using System;
using System.Collections.Generic;
using System.Text;

using ABB.Robotics.Math;
using ABB.Robotics.RobotStudio;
using ABB.Robotics.RobotStudio.Environment;
using ABB.Robotics.RobotStudio.Controllers;
using ABB.Robotics.Controllers;

namespace $safeprojectname$
{
    public class Class1
    {
        static Controller _controller;

        // This is the entry point which will be called when the Add-in is loaded
        public static void AddinMain()
        {
            // Create a ribbon group in the Controller tab with buttons to connect and disconnect to a controller
            var ribbonGroup = new RibbonGroup(null, "$safeprojectname$");
            UIEnvironment.RibbonTabs["Controller"].Groups.Add(ribbonGroup);

            string cmdId = "$safeprojectname$.Connect";
            var btnConnect = new CommandBarButton(cmdId, "Connect");
            ribbonGroup.Controls.Add(btnConnect);
            btnConnect.UpdateCommandUI += BtnConnect_UpdateCommandUI;
            btnConnect.ExecuteCommand += BtnConnect_ExecuteCommand;

            cmdId = "$safeprojectname$.Disconnect";
            var btnDisconnect = new CommandBarButton(cmdId, "Disconnect");
            ribbonGroup.Controls.Add(btnDisconnect);
            btnDisconnect.UpdateCommandUI += BtnDisconnect_UpdateCommandUI;
            btnDisconnect.ExecuteCommand += BtnDisconnect_ExecuteCommand;
        }

        private static void BtnConnect_UpdateCommandUI(object sender, UpdateCommandUIEventArgs e)
        {
            e.Enabled = _controller == null && ControllerManager.SelectedControllerObject != null;
        }

        private static void BtnConnect_ExecuteCommand(object sender, ExecuteCommandEventArgs e)
        {
            // Create a PCSDK connection to the controller that is selected in the controller browser
            var selectedController = ControllerManager.SelectedControllerObject.Root;
            _controller = Controller.Connect(selectedController.SystemId, ConnectionType.RobotStudio);
            Logger.AddMessage("$safeprojectname$: connected to " + _controller.Name);
        }

        private static void BtnDisconnect_UpdateCommandUI(object sender, UpdateCommandUIEventArgs e)
        {
            e.Enabled = _controller != null;
        }

        private static void BtnDisconnect_ExecuteCommand(object sender, ExecuteCommandEventArgs e)
        {
            _controller.Dispose();
            _controller = null;
            Logger.AddMessage("$safeprojectname$: disconnected from controller");
        }

    }
}