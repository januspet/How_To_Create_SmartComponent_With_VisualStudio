using ABB.Robotics.Math;
using ABB.Robotics.RobotStudio;
using ABB.Robotics.RobotStudio.Environment;
using ABB.Robotics.RobotStudio.Stations;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Integration;

namespace $safeprojectname$
{
    public class Class1
    {
        static bool _button2State = true;
        static DocumentWindow _formsWindow, _wpfWindow;

        // This is the entry point which will be called when the Add-in is loaded
        public static void AddinMain()
        {
            // Handle events from controls defined in CommandBarControls.xml
            RegisterCommand("$safeprojectname$.StartButton");
            RegisterCommand("$safeprojectname$.CloseButton");
            RegisterCommand("$safeprojectname$.Button1");
            RegisterCommand("$safeprojectname$.Button2");
            RegisterCommand("$safeprojectname$.ShowWinForm");
            RegisterCommand("$safeprojectname$.ShowWPF");
            RegisterCommand("$safeprojectname$.GalleryButton1");

            CommandBarComboBox comboBox = CommandBarComboBox.FromID("$safeprojectname$.ComboBox1");
            comboBox.SelectionChanged += comboBox_SelectionChanged;

            CommandBarGalleryPopup gallery = CommandBarGalleryPopup.FromID("$safeprojectname$.Gallery1");
            gallery.UpdateContent += gallery_UpdateContent;
        }

        static void RegisterCommand(string id)
        {
            var button = CommandBarButton.FromID(id);
            button.UpdateCommandUI += button_UpdateCommandUI;
            button.ExecuteCommand += button_ExecuteCommand;
        }

        static void button_UpdateCommandUI(object sender, UpdateCommandUIEventArgs e)
        {
            switch (e.Id)
            {
                case "$safeprojectname$.StartButton":
                case "$safeprojectname$.CloseButton":
                    e.Enabled = true;
                    break;
                case "$safeprojectname$.Button1":
                    e.Enabled = true;
                    break;
                case "$safeprojectname$.Button2":
                    e.Enabled = true;
                    e.Checked = _button2State;
                    break;
                case "$safeprojectname$.ShowWinForm":
                case "$safeprojectname$.ShowWPF":
                    e.Enabled = true;
                    break;
                case "$safeprojectname$.GalleryButton1":
                    e.Enabled = true;
                    break;
            }
        }

        static void button_ExecuteCommand(object sender, ExecuteCommandEventArgs e)
        {
            switch (e.Id)
            {
                case "$safeprojectname$.StartButton":
                    {
                        // Show and activate the add-in tab
                        RibbonTab ribbonTab = UIEnvironment.RibbonTabs["$safeprojectname$.Tab1"];
                        ribbonTab.Visible = true;
                        UIEnvironment.ActiveRibbonTab = ribbonTab;
                    }
                    break;
                case "$safeprojectname$.CloseButton":
                    {
                        // Close any created windows
                        _formsWindow?.Close();
                        _formsWindow = null;
                        _wpfWindow?.Close();
                        _wpfWindow = null;

                        // Hide the add-in tab
                        RibbonTab ribbonTab = UIEnvironment.RibbonTabs["$safeprojectname$.Tab1"];
                        ribbonTab.Visible = false;
                    }
                    break;
                case "$safeprojectname$.Button1":
                    Logger.AddMessage("$projectname$: Button1 pressed");
                    break;
                case "$safeprojectname$.Button2":
                    Logger.AddMessage("$projectname$: Button2 pressed");
                    _button2State = !_button2State;
                    break;
                case "$safeprojectname$.ShowWinForm":
                    if (_formsWindow == null)
                    {
                        // Create a new DocumentWindow with a Windows Forms control
                        _formsWindow = new DocumentWindow(null, new WinFormsControl(), "Windows Forms sample");
                        _formsWindow.Closing += (s, e1) =>
                        {
                            if (MessageBox.Show(UIEnvironment.MainWindow, "Close window?", "Closing", MessageBoxButtons.YesNo) == DialogResult.No)
                            {
                                e1.Cancel = true;
                            }
                        };
                        _formsWindow.Closed += (s, e1) =>
                        {
                            _formsWindow = null;
                        };
                        UIEnvironment.Windows.Add(_formsWindow);
                    }
                    else
                    {
                        // Bring existing window to front
                        _formsWindow.ActiveTab = true;
                    }
                    break;
                case "$safeprojectname$.ShowWPF":
                    if (_wpfWindow == null)
                    {
                        // Create a new DocumentWindow with a WPF control
                        var wpfHost = new ElementHost();
                        wpfHost.Child = new WPFControl();
                        _wpfWindow = new DocumentWindow(null, wpfHost, "WPF Sample");
                        _wpfWindow.Closed += (s, e1) =>
                        {
                            _wpfWindow = null;
                        };
                        UIEnvironment.Windows.Add(_wpfWindow);
                    }
                    else
                    {
                        // Bring existing window to front
                        _wpfWindow.ActiveTab = true;
                    }
                    break;

                case "$safeprojectname$.GalleryButton1":
                    Logger.AddMessage("$projectname$: GalleryButton1 pressed");
                    break;
            }
        }

        static void gallery_UpdateContent(object sender, EventArgs e)
        {
            var gallery = (CommandBarGalleryPopup)sender;

            // Add a button to the gallery
            var button = new CommandBarButton(null, "Dynamically added button");
            button.HelpText = "The quick brown fox jumps over the lazy dog";
            button.DefaultEnabled = true;
            button.ExecuteCommand += (s1, e1) =>
            {
                Logger.AddMessage("$projectname$: Dynamically added button clicked");
            };
            gallery.GalleryControls.Add(button);

            // Unsubscribe from update event
            gallery.UpdateContent -= gallery_UpdateContent;
        }

        static void comboBox_SelectionChanged(object sender, EventArgs e)
        {
            var comboBox = (CommandBarComboBox)sender;
            Logger.AddMessage(string.Format("$projectname$: Item '{0}' selected", comboBox.SelectedItem.Tag));
        }

    }
}